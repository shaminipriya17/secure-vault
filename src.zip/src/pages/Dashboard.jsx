import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect, useRef } from "react";
import {
  FiShield, FiUsers, FiDatabase, FiActivity,
  FiAlertTriangle, FiCheckCircle, FiClock, FiArrowUpRight,
  FiArrowDownRight, FiLock, FiUnlock, FiEye, FiMoreHorizontal,
  FiRefreshCw, FiDownload, FiFilter, FiZap, FiGlobe,
  FiTrendingUp, FiKey, FiServer
} from "react-icons/fi";

const T = {
  bg0: "#070B14", bg1: "#0B1220", bg2: "#111827", bg3: "#1a2235",
  bg4: "#1f2a3d", glass: "rgba(255,255,255,0.03)",
  glassBorder: "rgba(255,255,255,0.07)",
  primary: "#6366F1", primaryGlow: "rgba(99,102,241,0.15)",
  secondary: "#06B6D4", secondaryGlow: "rgba(6,182,212,0.15)",
  accent: "#8B5CF6", accentGlow: "rgba(139,92,246,0.15)",
  success: "#10B981", successGlow: "rgba(16,185,129,0.12)",
  warning: "#F59E0B", warningGlow: "rgba(245,158,11,0.12)",
  danger: "#EF4444", dangerGlow: "rgba(239,68,68,0.12)",
  info: "#06B6D4",
  text0: "#F8FAFC", text1: "#CBD5E1", text2: "#94A3B8", text3: "#64748B",
  radius: "14px", radiusSm: "10px", radiusLg: "20px",
};

const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  show: (i = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.45, delay: i * 0.07, ease: [0.22, 1, 0.36, 1] } }),
};

const glassCard = (extra = {}) => ({
  background: `linear-gradient(135deg, rgba(255,255,255,0.045) 0%, rgba(255,255,255,0.018) 100%)`,
  border: `1px solid ${T.glassBorder}`,
  borderRadius: T.radius,
  backdropFilter: "blur(20px)",
  WebkitBackdropFilter: "blur(20px)",
  ...extra,
});

const STAT_CARDS = [
  {
    id: "vaults",
    label: "Active Vaults",
    value: "1,284",
    delta: "+12.4%",
    up: true,
    icon: FiDatabase,
    color: T.primary,
    glow: T.primaryGlow,
    sub: "48 created this week",
  },
  {
    id: "users",
    label: "Authorized Users",
    value: "8,391",
    delta: "+3.7%",
    up: true,
    icon: FiUsers,
    color: T.secondary,
    glow: T.secondaryGlow,
    sub: "217 active right now",
  },
  {
    id: "threats",
    label: "Threats Blocked",
    value: "342",
    delta: "-8.1%",
    up: false,
    icon: FiShield,
    color: T.success,
    glow: T.successGlow,
    sub: "Down from last week",
  },
  {
    id: "keys",
    label: "Encryption Keys",
    value: "29,740",
    delta: "+1.2%",
    up: true,
    icon: FiKey,
    color: T.accent,
    glow: T.accentGlow,
    sub: "AES-256 & RSA-4096",
  },
];

const ACTIVITY_LOG = [
  { id: 1, type: "access", icon: FiUnlock, color: T.success, msg: "Vault #VLT-4821 accessed", user: "Sarah K.", time: "2m ago", region: "US-East" },
  { id: 2, type: "threat", icon: FiAlertTriangle, color: T.warning, msg: "Brute-force attempt blocked", user: "Unknown", time: "7m ago", region: "CN-Shanghai" },
  { id: 3, type: "key", icon: FiKey, color: T.primary, msg: "Key rotation completed", user: "System", time: "14m ago", region: "EU-West" },
  { id: 4, type: "lock", icon: FiLock, color: T.accent, msg: "Vault #VLT-2203 sealed", user: "James R.", time: "31m ago", region: "US-West" },
  { id: 5, type: "access", icon: FiUnlock, color: T.success, msg: "Vault #VLT-9104 accessed", user: "Priya M.", time: "45m ago", region: "AP-Mumbai" },
  { id: 6, type: "threat", icon: FiAlertTriangle, color: T.danger, msg: "Credential leak detected", user: "System", time: "1h ago", region: "EU-London" },
  { id: 7, type: "server", icon: FiServer, color: T.secondary, msg: "Node failover completed", user: "System", time: "2h ago", region: "US-East" },
];

const VAULT_HEALTH = [
  { label: "Encrypted", pct: 94, color: T.success },
  { label: "Pending Rotation", pct: 4, color: T.warning },
  { label: "At Risk", pct: 2, color: T.danger },
];

const REGION_DATA = [
  { region: "US-East", vaults: 412, threats: 18, status: "healthy" },
  { region: "EU-West", vaults: 318, threats: 7, status: "healthy" },
  { region: "AP-Mumbai", vaults: 201, threats: 3, status: "healthy" },
  { region: "US-West", vaults: 198, threats: 12, status: "warning" },
  { region: "CN-Shanghai", vaults: 155, threats: 41, status: "critical" },
];

const QUICK_ACTIONS = [
  { label: "New Vault", icon: FiDatabase, color: T.primary },
  { label: "Rotate Keys", icon: FiRefreshCw, color: T.accent },
  { label: "Audit Log", icon: FiDownload, color: T.secondary },
  { label: "Threat Scan", icon: FiZap, color: T.warning },
];

function MiniBarChart({ data, color }) {
  const max = Math.max(...data);
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 40 }}>
      {data.map((v, i) => (
        <motion.div
          key={i}
          initial={{ height: 0 }}
          animate={{ height: `${(v / max) * 100}%` }}
          transition={{ duration: 0.6, delay: i * 0.04, ease: [0.22, 1, 0.36, 1] }}
          style={{
            flex: 1, borderRadius: 3,
            background: i === data.length - 1
              ? color
              : `linear-gradient(to top, ${color}55, ${color}22)`,
            minWidth: 4,
          }}
        />
      ))}
    </div>
  );
}

function SparkLine({ data, color }) {
  const w = 90, h = 32;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / (max - min || 1)) * h;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg width={w} height={h} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`sg-${color.replace("#","")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline
        points={pts}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function RingGauge({ pct, color, size = 56 }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;
  return (
    <svg width={size} height={size}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={`${color}22`} strokeWidth={6} />
      <motion.circle
        cx={size / 2} cy={size / 2} r={r}
        fill="none" stroke={color} strokeWidth={6}
        strokeLinecap="round"
        strokeDasharray={circ}
        initial={{ strokeDashoffset: circ }}
        animate={{ strokeDashoffset: circ - dash }}
        transition={{ duration: 1.2, ease: [0.22, 1, 0.36, 1] }}
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
      />
      <text x={size / 2} y={size / 2 + 5} textAnchor="middle"
        style={{ fontSize: 13, fontWeight: 700, fill: color, fontFamily: "inherit" }}>
        {pct}%
      </text>
    </svg>
  );
}

function StatusDot({ status }) {
  const map = { healthy: T.success, warning: T.warning, critical: T.danger };
  const c = map[status] || T.text3;
  return (
    <span style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
      <motion.span
        animate={{ scale: [1, 1.8, 1], opacity: [0.7, 0, 0.7] }}
        transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
        style={{
          position: "absolute", inset: 0, borderRadius: "50%",
          background: c, display: "block",
        }}
      />
      <span style={{ width: 8, height: 8, borderRadius: "50%", background: c, display: "block", position: "relative" }} />
    </span>
  );
}

export default function Dashboard() {
  const [time, setTime] = useState(new Date());
  const [activeFilter, setActiveFilter] = useState("all");
  const [logFilter, setLogFilter] = useState("all");
  const [hoveredStat, setHoveredStat] = useState(null);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const sparkData = {
    vaults: [38, 42, 39, 51, 47, 58, 61, 55, 67, 72, 69, 80],
    users: [210, 195, 220, 215, 230, 218, 240, 228, 251, 244, 260, 255],
    threats: [22, 30, 18, 25, 14, 19, 12, 17, 10, 15, 8, 11],
    keys: [900, 920, 910, 940, 935, 960, 955, 975, 970, 990, 985, 1010],
  };

  const barData = [28, 34, 31, 42, 38, 51, 46, 58, 54, 67, 62, 74];

  const filteredLog = logFilter === "all"
    ? ACTIVITY_LOG
    : ACTIVITY_LOG.filter(e => e.type === logFilter);

  const fmt = (d) => d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", second: "2-digit" });

  return (
    <div style={{ minHeight: "100vh", background: T.bg0, padding: "28px 32px 48px", fontFamily: "'Inter', 'SF Pro Display', system-ui, sans-serif", color: T.text0 }}>

      {/* ── Header ─────────────────────────────────────────── */}
      <motion.div
        variants={fadeUp} initial="hidden" animate="show" custom={0}
        style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 32, flexWrap: "wrap", gap: 16 }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: T.success, boxShadow: `0 0 8px ${T.success}` }} />
            <span style={{ fontSize: 12, color: T.text2, letterSpacing: "0.08em", textTransform: "uppercase", fontWeight: 500 }}>
              All systems operational
            </span>
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, color: T.text0, margin: 0, letterSpacing: "-0.02em" }}>
            Security Overview
          </h1>
          <p style={{ margin: "4px 0 0", color: T.text2, fontSize: 14 }}>
            SecureVault Enterprise · Real-time monitoring
          </p>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <div style={{ ...glassCard(), padding: "8px 16px", display: "flex", alignItems: "center", gap: 8 }}>
            <FiClock size={13} color={T.text3} />
            <span style={{ fontSize: 13, color: T.text2, fontVariantNumeric: "tabular-nums" }}>{fmt(time)}</span>
          </div>
          {QUICK_ACTIONS.map((a, i) => (
            <motion.button
              key={a.label}
              whileHover={{ scale: 1.04, y: -1 }}
              whileTap={{ scale: 0.96 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0, transition: { delay: 0.1 + i * 0.06 } }}
              style={{
                ...glassCard(),
                padding: "8px 14px", border: `1px solid ${a.color}33`,
                display: "flex", alignItems: "center", gap: 7,
                cursor: "pointer", color: a.color, fontSize: 13, fontWeight: 500,
                background: `linear-gradient(135deg, ${a.color}12, ${a.color}05)`,
              }}
            >
              <a.icon size={14} />
              {a.label}
            </motion.button>
          ))}
        </div>
      </motion.div>

      {/* ── Stat Cards ─────────────────────────────────────── */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
        gap: 18, marginBottom: 24,
      }}>
        {STAT_CARDS.map((card, i) => (
          <motion.div
            key={card.id}
            variants={fadeUp} initial="hidden" animate="show" custom={i + 1}
            whileHover={{ y: -4, transition: { duration: 0.25 } }}
            onHoverStart={() => setHoveredStat(card.id)}
            onHoverEnd={() => setHoveredStat(null)}
            style={{
              ...glassCard(),
              padding: "22px 22px 18px",
              position: "relative", overflow: "hidden",
              cursor: "default",
              boxShadow: hoveredStat === card.id ? `0 0 0 1px ${card.color}44, 0 16px 40px ${card.color}18` : "none",
              transition: "box-shadow 0.3s ease",
            }}
          >
            <div style={{
              position: "absolute", top: -30, right: -30,
              width: 110, height: 110, borderRadius: "50%",
              background: card.glow, filter: "blur(28px)", pointerEvents: "none",
            }} />

            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
              <div style={{
                width: 40, height: 40, borderRadius: 10,
                background: `linear-gradient(135deg, ${card.color}28, ${card.color}10)`,
                border: `1px solid ${card.color}33`,
                display: "flex", alignItems: "center", justifyContent: "center",
              }}>
                <card.icon size={18} color={card.color} />
              </div>
              <SparkLine data={sparkData[card.id]} color={card.color} />
            </div>

            <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: "-0.03em", color: T.text0, lineHeight: 1 }}>
              {card.value}
            </div>
            <div style={{ fontSize: 13, color: T.text2, margin: "4px 0 10px" }}>{card.label}</div>

            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
                {card.up ? <FiArrowUpRight size={13} color={T.success} /> : <FiArrowDownRight size={13} color={card.up === false ? T.success : T.danger} />}
                <span style={{ fontSize: 12, color: card.up ? T.success : T.success, fontWeight: 600 }}>{card.delta}</span>
              </div>
              <span style={{ fontSize: 11, color: T.text3 }}>{card.sub}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* ── Middle Row ─────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 340px", gap: 18, marginBottom: 24 }}>

        {/* Access Volume Chart */}
        <motion.div
          variants={fadeUp} initial="hidden" animate="show" custom={5}
          style={{ ...glassCard(), padding: "22px 22px 18px", gridColumn: "1 / 2" }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 600, color: T.text0 }}>Access Volume</div>
              <div style={{ fontSize: 12, color: T.text3, marginTop: 2 }}>Last 12 months</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {["1W", "1M", "3M", "1Y"].map(f => (
                <button
                  key={f}
                  onClick={() => setActiveFilter(f)}
                  style={{
                    padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 500,
                    border: `1px solid ${activeFilter === f ? T.primary : T.glassBorder}`,
                    background: activeFilter === f ? `${T.primary}22` : "transparent",
                    color: activeFilter === f ? T.primary : T.text3,
                    cursor: "pointer", transition: "all 0.2s",
                  }}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "flex-end", gap: 5, height: 120 }}>
            {barData.map((v, i) => {
              const max = Math.max(...barData);
              const months = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
              const isLast = i === barData.length - 1;
              return (
                <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${(v / max) * 100}px` }}
                    transition={{ duration: 0.7, delay: 0.4 + i * 0.04, ease: [0.22, 1, 0.36, 1] }}
                    style={{
                      width: "100%", borderRadius: "5px 5px 3px 3px",
                      background: isLast
                        ? `linear-gradient(to top, ${T.primary}, ${T.accent})`
                        : `linear-gradient(to top, ${T.primary}55, ${T.primary}22)`,
                      boxShadow: isLast ? `0 0 16px ${T.primary}44` : "none",
                      position: "relative",
                    }}
                  />
                  <span style={{ fontSize: 9, color: T.text3 }}>{months[i]}</span>
                </div>
              );
            })}
          </div>

          <div style={{ display: "flex", gap: 24, marginTop: 16, paddingTop: 14, borderTop: `1px solid ${T.glassBorder}` }}>
            {[{ label: "Total Accesses", val: "89,241" }, { label: "Avg. / day", val: "7,437" }, { label: "Peak", val: "Dec" }].map(s => (
              <div key={s.label}>
                <div style={{ fontSize: 16, fontWeight: 700, color: T.text0 }}>{s.val}</div>
                <div style={{ fontSize: 11, color: T.text3, marginTop: 2 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Threat Intelligence */}
        <motion.div
          variants={fadeUp} initial="hidden" animate="show" custom={6}
          style={{ ...glassCard(), padding: "22px 22px 18px" }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 600, color: T.text0 }}>Threat Intelligence</div>
              <div style={{ fontSize: 12, color: T.text3, marginTop: 2 }}>Live feed</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, background: `${T.danger}18`, border: `1px solid ${T.danger}33`, borderRadius: 6, padding: "5px 10px" }}>
              <motion.div
                animate={{ opacity: [1, 0.3, 1] }}
                transition={{ repeat: Infinity, duration: 1.4 }}
                style={{ width: 6, height: 6, borderRadius: "50%", background: T.danger }}
              />
              <span style={{ fontSize: 11, color: T.danger, fontWeight: 600 }}>LIVE</span>
            </div>
          </div>

          {[
            { label: "Brute Force", count: 142, pct: 41, color: T.danger },
            { label: "Credential Stuffing", count: 89, pct: 26, color: T.warning },
            { label: "SQL Injection", count: 61, pct: 18, color: T.accent },
            { label: "Phishing", count: 50, pct: 15, color: T.primary },
          ].map((t, i) => (
            <div key={t.label} style={{ marginBottom: 14 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                <span style={{ fontSize: 12, color: T.text1 }}>{t.label}</span>
                <span style={{ fontSize: 12, color: t.color, fontWeight: 600 }}>{t.count}</span>
              </div>
              <div style={{ height: 5, borderRadius: 3, background: `${t.color}20`, overflow: "hidden" }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${t.pct}%` }}
                  transition={{ duration: 0.9, delay: 0.5 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                  style={{ height: "100%", borderRadius: 3, background: `linear-gradient(to right, ${t.color}, ${t.color}aa)` }}
                />
              </div>
            </div>
          ))}

          <div style={{
            marginTop: 8, padding: "12px 14px", borderRadius: T.radiusSm,
            background: `${T.warning}12`, border: `1px solid ${T.warning}28`,
            display: "flex", alignItems: "center", gap: 10,
          }}>
            <FiAlertTriangle size={14} color={T.warning} />
            <span style={{ fontSize: 12, color: T.text1 }}>Elevated risk from <strong style={{ color: T.warning }}>CN-Shanghai</strong> — 41 attempts blocked today</span>
          </div>
        </motion.div>

        {/* Vault Health */}
        <motion.div
          variants={fadeUp} initial="hidden" animate="show" custom={7}
          style={{ ...glassCard(), padding: "22px 22px 18px" }}
        >
          <div style={{ fontSize: 15, fontWeight: 600, color: T.text0, marginBottom: 4 }}>Vault Health</div>
          <div style={{ fontSize: 12, color: T.text3, marginBottom: 20 }}>Encryption status across all nodes</div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {VAULT_HEALTH.map((v, i) => (
              <div key={v.label} style={{ display: "flex", alignItems: "center", gap: 14 }}>
                <RingGauge pct={v.pct} color={v.color} size={54} />
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: T.text0 }}>{v.label}</div>
                  <div style={{ fontSize: 12, color: T.text3 }}>{Math.round(1284 * v.pct / 100).toLocaleString()} vaults</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 20, paddingTop: 16, borderTop: `1px solid ${T.glassBorder}` }}>
            <div style={{ fontSize: 12, color: T.text3, marginBottom: 8 }}>Next key rotation</div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <FiClock size={13} color={T.accent} />
              <span style={{ fontSize: 13, color: T.text1 }}>Auto-rotation in <strong style={{ color: T.accent }}>6h 24m</strong></span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* ── Bottom Row ─────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 18 }}>

        {/* Activity Log */}
        <motion.div
          variants={fadeUp} initial="hidden" animate="show" custom={8}
          style={{ ...glassCard(), padding: "22px 22px 18px" }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 600, color: T.text0 }}>Activity Log</div>
              <div style={{ fontSize: 12, color: T.text3, marginTop: 2 }}>Audit trail — last 24 hours</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              {["all", "access", "threat", "key"].map(f => (
                <button
                  key={f}
                  onClick={() => setLogFilter(f)}
                  style={{
                    padding: "4px 10px", borderRadius: 6, fontSize: 11, fontWeight: 500,
                    border: `1px solid ${logFilter === f ? T.primary : T.glassBorder}`,
                    background: logFilter === f ? `${T.primary}22` : "transparent",
                    color: logFilter === f ? T.primary : T.text3,
                    cursor: "pointer", transition: "all 0.2s", textTransform: "capitalize",
                  }}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <AnimatePresence mode="popLayout">
              {filteredLog.map((entry, i) => (
                <motion.div
                  key={entry.id}
                  layout
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0, transition: { delay: i * 0.05 } }}
                  exit={{ opacity: 0, x: 10 }}
                  whileHover={{ background: "rgba(255,255,255,0.04)" }}
                  style={{
                    display: "flex", alignItems: "center", gap: 14,
                    padding: "10px 12px", borderRadius: T.radiusSm,
                    transition: "background 0.15s",
                  }}
                >
                  <div style={{
                    width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                    background: `${entry.color}18`, border: `1px solid ${entry.color}30`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}>
                    <entry.icon size={14} color={entry.color} />
                  </div>

                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, color: T.text1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {entry.msg}
                    </div>
                    <div style={{ fontSize: 11, color: T.text3, marginTop: 2 }}>
                      {entry.user} · <span style={{ color: T.text3 }}>{entry.region}</span>
                    </div>
                  </div>

                  <span style={{ fontSize: 11, color: T.text3, whiteSpace: "nowrap" }}>{entry.time}</span>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <button style={{
            width: "100%", marginTop: 12, padding: "10px",
            background: "transparent", border: `1px solid ${T.glassBorder}`,
            borderRadius: T.radiusSm, color: T.text2, fontSize: 13,
            cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
            transition: "all 0.2s",
          }}
            onMouseEnter={e => { e.target.style.borderColor = T.primary; e.target.style.color = T.primary; }}
            onMouseLeave={e => { e.target.style.borderColor = T.glassBorder; e.target.style.color = T.text2; }}
          >
            <FiEye size={13} /> View full audit log
          </button>
        </motion.div>

        {/* Regional Status */}
        <motion.div
          variants={fadeUp} initial="hidden" animate="show" custom={9}
          style={{ ...glassCard(), padding: "22px 22px 18px" }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 15, fontWeight: 600, color: T.text0 }}>Regional Nodes</div>
              <div style={{ fontSize: 12, color: T.text3, marginTop: 2 }}>Infrastructure health</div>
            </div>
            <FiGlobe size={16} color={T.text3} />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
            {REGION_DATA.map((r, i) => {
              const statusColor = { healthy: T.success, warning: T.warning, critical: T.danger }[r.status];
              return (
                <motion.div
                  key={r.region}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0, transition: { delay: 0.7 + i * 0.07 } }}
                  whileHover={{ background: "rgba(255,255,255,0.04)" }}
                  style={{
                    display: "flex", alignItems: "center", gap: 12,
                    padding: "10px 12px", borderRadius: T.radiusSm,
                    transition: "background 0.15s",
                  }}
                >
                  <StatusDot status={r.status} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, color: T.text1, fontWeight: 500 }}>{r.region}</div>
                    <div style={{ fontSize: 11, color: T.text3, marginTop: 2 }}>{r.vaults} vaults</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontSize: 12, color: r.threats > 20 ? T.danger : T.text2, fontWeight: 600 }}>
                      {r.threats} threats
                    </div>
                    <div style={{
                      fontSize: 10, color: statusColor, textTransform: "capitalize",
                      fontWeight: 500, marginTop: 2,
                    }}>
                      {r.status}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          <div style={{
            marginTop: 14, padding: "12px 14px", borderRadius: T.radiusSm,
            background: `${T.success}10`, border: `1px solid ${T.success}25`,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <FiCheckCircle size={13} color={T.success} />
              <span style={{ fontSize: 12, color: T.success, fontWeight: 600 }}>4 / 5 regions healthy</span>
            </div>
            <div style={{ display: "flex", gap: 16 }}>
              {[{ label: "Uptime", val: "99.97%" }, { label: "Latency", val: "12ms" }].map(s => (
                <div key={s.label}>
                  <div style={{ fontSize: 14, fontWeight: 700, color: T.text0 }}>{s.val}</div>
                  <div style={{ fontSize: 10, color: T.text3 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginTop: 12 }}>
            <div style={{ fontSize: 12, color: T.text3, marginBottom: 8 }}>Compliance coverage</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {["SOC 2 Type II", "ISO 27001", "GDPR", "HIPAA"].map(tag => (
                <span
                  key={tag}
                  style={{
                    fontSize: 10, padding: "3px 8px", borderRadius: 4,
                    background: `${T.primary}18`, border: `1px solid ${T.primary}30`,
                    color: T.primary, fontWeight: 500,
                  }}
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* ── Responsive styles ───────────────────────────────── */}
      <style>{`
        @media (max-width: 1280px) {
          .dash-mid { grid-template-columns: 1fr 1fr !important; }
          .dash-mid > :last-child { grid-column: 1 / -1; }
          .dash-bot { grid-template-columns: 1fr !important; }
        }
        @media (max-width: 768px) {
          .dash-mid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}
