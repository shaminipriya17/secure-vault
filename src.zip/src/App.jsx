import { useState, useEffect, useCallback, createContext, useContext } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import MainLayout from "./components/layout/MainLayout";
import PageContainer from "./components/layout/PageContainer";

// Lazy load pages for better performance
import Dashboard from "./pages/Dashboard";
import Login from "./pages/Login";
import Users from "./pages/Users";
import Vaults from "./pages/Vaults";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";
import Profile from "./pages/Profile";
import Notifications from "./pages/Notifications";

const T = {
  bg0: "#070B14",
  bg1: "#0B1220",
  bg2: "#111827",
  bg3: "#1a2235",
  primary: "#6366F1",
  secondary: "#06B6D4",
  text0: "#F8FAFC",
  text1: "#CBD5E1",
  text2: "#94A3B8",
  text3: "#64748B",
  border: "rgba(255,255,255,0.07)",
};

// Auth Context
const AuthContext = createContext();

const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};

const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const storedAuth = localStorage.getItem("auth");
        if (storedAuth) {
          const authData = JSON.parse(storedAuth);
          setUser(authData);
          setIsAuthenticated(true);
        }
      } catch (error) {
        console.error("Auth check failed:", error);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = useCallback((credentials) => {
    try {
      const userData = {
        id: "user_001",
        email: credentials.email,
        name: "Admin User",
        role: "Administrator",
        avatar: "AD",
        organization: "SecureVault",
      };
      setUser(userData);
      setIsAuthenticated(true);
      localStorage.setItem("auth", JSON.stringify(userData));
      return Promise.resolve(userData);
    } catch (error) {
      return Promise.reject(error);
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem("auth");
  }, []);

  const value = {
    isAuthenticated,
    user,
    loading,
    login,
    logout,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{
          width: "100%",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: `linear-gradient(135deg, ${T.bg0} 0%, ${T.bg1} 100%)`,
        }}
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          style={{
            width: "48px",
            height: "48px",
            borderRadius: "50%",
            border: `2px solid ${T.primary}`,
            borderTopColor: "transparent",
          }}
        />
      </motion.div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

// Public Route Component
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{
          width: "100%",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: `linear-gradient(135deg, ${T.bg0} 0%, ${T.bg1} 100%)`,
        }}
      >
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          style={{
            width: "48px",
            height: "48px",
            borderRadius: "50%",
            border: `2px solid ${T.primary}`,
            borderTopColor: "transparent",
          }}
        />
      </motion.div>
    );
  }

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

// Layout Wrapper for Protected Routes
const LayoutWrapper = ({ children }) => {
  return (
    <MainLayout>
      <PageContainer animated>
        {children}
      </PageContainer>
    </MainLayout>
  );
};

// Main App Component
const AppContent = () => {
  return (
    <AnimatePresence mode="wait">
      <Routes>
        {/* Public Routes */}
        <Route
          path="/login"
          element={
            <PublicRoute>
              <motion.div
                key="login"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Login />
              </motion.div>
            </PublicRoute>
          }
        />

        {/* Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <motion.div
                key="dashboard"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Dashboard />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/users"
          element={
            <ProtectedRoute>
              <motion.div
                key="users"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Users />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/vaults"
          element={
            <ProtectedRoute>
              <motion.div
                key="vaults"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Vaults />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/analytics"
          element={
            <ProtectedRoute>
              <motion.div
                key="analytics"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Analytics />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/security"
          element={
            <ProtectedRoute>
              <motion.div
                key="security"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <div style={{ color: T.text0 }}>Security Dashboard</div>
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/settings"
          element={
            <ProtectedRoute>
              <motion.div
                key="settings"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Settings />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <motion.div
                key="profile"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Profile />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        <Route
          path="/notifications"
          element={
            <ProtectedRoute>
              <motion.div
                key="notifications"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <LayoutWrapper>
                  <Notifications />
                </LayoutWrapper>
              </motion.div>
            </ProtectedRoute>
          }
        />

        {/* Redirect root to dashboard or login */}
        <Route
          path="/"
          element={<Navigate to="/dashboard" replace />}
        />

        {/* 404 Route */}
        <Route
          path="*"
          element={
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              style={{
                width: "100%",
                height: "100vh",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                background: `linear-gradient(135deg, ${T.bg0} 0%, ${T.bg1} 100%)`,
                flexDirection: "column",
                gap: "24px",
                color: T.text0,
              }}
            >
              <div style={{ fontSize: "48px", fontWeight: 700 }}>404</div>
              <div style={{ fontSize: "18px", color: T.text2 }}>Page not found</div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => window.location.href = "/"}
                style={{
                  padding: "12px 24px",
                  background: T.primary,
                  color: T.text0,
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  fontSize: "14px",
                  fontWeight: 600,
                  transition: "all 0.2s ease",
                }}
              >
                Go back home
              </motion.button>
            </motion.div>
          }
        />
      </Routes>
    </AnimatePresence>
  );
};

// Root App Component
const App = () => {
  return (
    <Router>
      <AuthProvider>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          style={{
            width: "100%",
            minHeight: "100vh",
            background: T.bg0,
            color: T.text0,
            fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', sans-serif",
          }}
        >
          <style>{`
            * {
              margin: 0;
              padding: 0;
              box-sizing: border-box;
            }

            html, body, #root {
              width: 100%;
              height: 100%;
              margin: 0;
              padding: 0;
            }

            body {
              background: ${T.bg0};
              color: ${T.text0};
              overflow: hidden;
            }

            button {
              font-family: inherit;
            }

            input, textarea, select {
              font-family: inherit;
            }

            ::-webkit-scrollbar {
              width: 8px;
              height: 8px;
            }

            ::-webkit-scrollbar-track {
              background: transparent;
            }

            ::-webkit-scrollbar-thumb {
              background: rgba(99, 102, 241, 0.3);
              border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb:hover {
              background: rgba(99, 102, 241, 0.5);
            }
          `}</style>
          <AppContent />
        </motion.div>
      </AuthProvider>
    </Router>
  );
};

export default App;
export { useAuth, AuthProvider };
